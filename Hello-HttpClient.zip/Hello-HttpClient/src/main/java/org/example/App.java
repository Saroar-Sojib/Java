package org.example;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.mysql.cj.jdbc.Driver;


import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.List;

public class App
{
    public static final String POSTS_API_URL = "https://jsonplaceholder.typicode.com/posts";
    public static void main( String[] args ) throws IOException, InterruptedException {
         HttpClient client=HttpClient.newHttpClient();
         HttpRequest request=HttpRequest.newBuilder()
                 .GET()
                 .header("accept", "application/json")
                 .uri(URI.create(POSTS_API_URL))
                 .build();
        HttpResponse<String>response = client.send(request, HttpResponse.BodyHandlers.ofString());
        ObjectMapper mapper=new ObjectMapper();

        List<Read> posts = mapper.readValue(response.body(), new TypeReference<List<Read>>() {});
        posts.forEach(System.out::println);
        try{
            String driver="com.mysql.cj.jdbc.Driver";
            String url="jdbc:mysql://localhost:3306/test";
            String username="root";
            String password="";

            Class.forName(driver);
            Connection con = DriverManager.getConnection(url,username,password);
            System.out.println("Connection Success");
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }

    }
}
